// JavaScript Document

function onClick(){
	
	document.getElementById('sub-menu').style.cssText='height:100px; transition:all 0.4s ease-in-out';
	
	

}

function onmouseOut(){
	
	document.getElementById('sub-menu').style.cssText='height:0px;transition:all 0.4s ease-in-out';
	

}


function loginPopup(){
	
	document.getElementById('log-in-page').style.cssText='display:block';
	

}
function loginClose(){
	
	document.getElementById('log-in-page').style.cssText='display:none';
	

}

function signupPopup(){
	
	document.getElementById('sign-up-page').style.cssText='display:block';
	

}
function signupClose(){
	
	document.getElementById('sign-up-page').style.cssText='display:none';
	

}